-- Drop View forestation
DROP VIEW IF EXISTS forestation;

-- Create View forestation
CREATE VIEW forestation AS

SELECT fa.country_code AS country_code  , fa.country_name AS country_name , 
  fa.year AS "year" , fa.forest_area_sqkm AS forest_area_sqkm ,
  la.total_area_sq_mi AS total_area_sq_mi , 
  r.region AS region , r.income_group AS income_group,
  (fa.forest_area_sqkm/2.59)/ 
  la.total_area_sq_mi * 100 AS forest_percent
  
FROM forest_area fa
JOIN land_area la ON fa.country_code  = la.country_code AND fa.year  = la.year
JOIN regions r ON r.country_code = la.country_code;

--Check forestation view
SELECT * FROM forestation
LIMIT 3 ;
--country_code	country_name	year	forest_area_sqkm	total_area_sq_mi	region	income_group	forest_percent
--        ABW	Aruba	2016	4.199999869	69.5	Latin America & Caribbean	    High income	2.33326844754312
--        AFG	Afghanistan	2016	13500	252069.5	South Asia					Low income	2.06782463263315
--        AGO	Angola	2016	577311.9922	481351.35	Sub-Saharan Africa			Lower middle income	46.3072105414897


-- total forest area of the world in 1990 and 2016
SELECT *
FROM forest_area
WHERE country_name = 'World' and (year=1990 or year=2016);
--country_code	country_name	year	forest_area_sqkm
--WLD	                 World	 2016	39958245.9
--WLD	                 World	1990	41282694.9

--  Difference of total forest area of the world in 1990 and 2016
SELECT  
  (fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm)
  AS Difference
FROM forest_area AS fa_2016
JOIN forest_area AS fa_1990
  ON  (fa_2016.year = '2016' AND fa_1990.year = '1990'
  AND fa_2016.country_name = 'World' AND fa_1990.country_name = 'World');
-- Difference
-- -1324449
 
--  Percent loss of total forest area of the world in 1990 and 2016 
SELECT  
  Round(Cast(100.0*(fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) / 
  fa_1990.forest_area_sqkm AS NUMERIC), 2) AS Percentage
FROM forest_area AS fa_2016
JOIN forest_area AS fa_1990
  ON  (fa_2016.year = '2016' AND fa_1990.year = '1990'
  AND fa_2016.country_name = 'World' AND fa_1990.country_name = 'World');
-- Percentage
-- -3.21

-- country's total area closest to amount of forest area lost between 1990 and 2016 
SELECT country_name,(total_area_sq_mi*2.59) as total_area, MIN(1324449 - (total_area_sq_mi*2.59)) as closest_diff_area
FROM forestation
WHERE year = '2016' AND (total_area_sq_mi*2.59) IS NOT NULL 
GROUP BY 1,2
Having MIN(1324449 - (total_area_sq_mi*2.59))> 0
order by 3
LIMIT 1;
--country_name	total_area	closest_diff_area
--     Peru	1279999.9891	44449.0109000001

-- Percentage of forest of the entire world in 2016 and 1990
SELECT t.year,t.country_name, max(t.forest_percent)
from
(SELECT year,country_name, forest_percent
FROM forestation
WHERE (year = 2016 OR year = 1990)  AND country_name = 'World'
ORDER BY 3 DESC )as t
Group by 1,2
--year	country_name	max
--1990	World	    32.4264982823657
--2016	World	    31.3861775540893

WITH tb1 AS
 (SELECT SUM(a.forest_area_sqkm/ 2.59) region_forest_1990,
  SUM(a.total_area_sq_mi) region_area_1990, a.region
FROM  forestation a
WHERE  a.year = '1990'
GROUP  BY 3) ,

tb2 AS 
(SELECT SUM(b.forest_area_sqkm/ 2.59) region_forest_2016,
  SUM(b.total_area_sq_mi) region_area_2016, b.region
FROM  forestation b
WHERE  b.year = '2016'
GROUP  BY 3)

SELECT tb1.region,Round(Cast(( tb1.region_forest_1990 / tb1.region_area_1990 * 100) AS NUMERIC), 2) AS forest_percent_1990,
Round(Cast(( tb2.region_forest_2016 / tb2.region_area_2016 * 100) AS NUMERIC), 2) AS forest_percent_2016
FROM tb1
JOIN tb2  ON tb1.region = tb2.region;
--region	forest_percent_1990	forest_percent_2016
--Latin America & Caribbean	51.03	46.16
--Sub-Saharan Africa	30.67	28.79
--Europe & Central Asia	37.28	38.04
--East Asia & Pacific	25.78	26.36
--South Asia	16.51	17.51
--Middle East & North Africa	1.78	2.07
--World	32.42	31.38
--North America	35.65	36.04

                     
--countries that increased in forest area from 1990 to 2016 					 
SELECT fa_2016.country_name, 
  (fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) AS difference
FROM forest_area AS fa_2016
JOIN forest_area AS fa_1990
  ON  (fa_2016.year = '2016' AND fa_1990.year = '1990')
  AND fa_2016.country_name = fa_1990.country_name
Where (fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) is not null
ORDER BY difference DESC
limit 2;
--country_name	difference
--China	527229.062
--United States	79200

--countries that increased in percent forest area from 1990 to 2016 
SELECT fa_2016.country_name, 
   Round(Cast(100.0*(fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) / 
  (fa_1990.forest_area_sqkm) AS NUMERIC), 2) AS percentage
FROM forest_area AS fa_2016
JOIN forest_area AS fa_1990
  ON  (fa_2016.year = '2016' AND fa_1990.year = '1990')
  AND fa_2016.country_name = fa_1990.country_name
Where (fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) is not null
ORDER BY percentage DESC
limit 2;
--country_name	percentage
--Iceland	213.66
--French Polynesia	181.82

--countries and regions had the largest decrease in forest area over the time period 1990 & 2016
SELECT fa_2016.country_name, r.region,
  (fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) AS difference
FROM forest_area AS fa_2016
JOIN forest_area AS fa_1990
  ON  (fa_2016.year = '2016' AND fa_1990.year = '1990')
  AND fa_2016.country_name = fa_1990.country_name
JOIN regions As r ON fa_1990.country_name=r.country_name
Where (fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) is not null
ORDER BY difference
limit 10;
--country_name	region	difference
--World	World	-1324449
--Brazil	Latin America & Caribbean	-541510
--Indonesia	East Asia & Pacific	-282193.9844
--Myanmar	East Asia & Pacific	-107234.0039
--Nigeria	Sub-Saharan Africa	-106506.00098
--Tanzania	Sub-Saharan Africa	-102320

--countries and regions had the largest decrease in percent forest area over the time period 1990 & 2016
SELECT fa_2016.country_name, r.region,
   Round(Cast(100.0*(fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) / 
  fa_1990.forest_area_sqkm AS NUMERIC), 2) AS percentage
FROM forest_area AS fa_2016
JOIN forest_area AS fa_1990
  ON  (fa_2016.year = '2016' AND fa_1990.year = '1990')
  AND fa_2016.country_name = fa_1990.country_name
JOIN regions As r ON fa_1990.country_name=r.country_name
Where (fa_2016.forest_area_sqkm - fa_1990.forest_area_sqkm) is not null
ORDER BY percentage 
limit 10;
--country_name	region	percentage
--Togo	Sub-Saharan Africa	-75.45
--Nigeria	Sub-Saharan Africa	-61.80
--Uganda	Sub-Saharan Africa	-59.13
--Mauritania	Sub-Saharan Africa	-46.75
--Honduras	Latin America & Caribbean	-45.03

--Count of Countries Grouped by Forestation Percent Quartiles, 2016
SELECT distinct(quartiles), COUNT(country_name) OVER (PARTITION BY quartiles)
FROM (SELECT country_name,
  CASE WHEN forest_percent <= 25 THEN 'Q1:0-25%'
  WHEN forest_percent<= 75 AND forest_percent > 50 THEN 'Q2:50-75%'
  WHEN forest_percent <= 50 AND forest_percent > 25 THEN 'Q3:25-50%'
  ELSE 'Q4:75-100%'
END AS quartiles FROM forestation
WHERE forest_percent IS NOT NULL AND year = 2016 AND  country_name<>'World') quart;
--quartiles	count
--Q1:0-25%	85
--Q2:50-75%	38
--Q3:25-50%	72
--Q4:75-100%	9

--Top Quartile Countries, 2016
SELECT f.country_name,r.region, Round(Cast(max(forest_percent)AS NUMERIC), 2)
FROM forestation f
JOIN regions As r ON f.country_name=r.country_name
WHERE (forest_percent > 75) AND year = 2016
group by 1,2
order by 3 desc;
--country_name	region	round
--Suriname	Latin America & Caribbean	98.26
--Micronesia, Fed. Sts.	East Asia & Pacific	91.86
--Gabon	Sub-Saharan Africa	90.04
--Seychelles	Sub-Saharan Africa	88.41
--Palau	East Asia & Pacific	87.61
--American Samoa	East Asia & Pacific	87.50
--Guyana	Latin America & Caribbean	83.90
--Lao PDR	East Asia & Pacific	82.11
--Solomon Islands	East Asia & Pacific	77.86









  
  
