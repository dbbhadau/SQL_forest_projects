--1. Topic descriptions can all be empty
--2. Since the bad_comments table doesn’t have the threading feature, you can migrate all
--comments as top-level comments, i.e. without a parent
--3. You can use the Postgres string function regexp_split_to_table to unwind the commaseparated votes values into separate ---rows
--4. Don’t forget that some users only vote or comment, and haven’t created any posts. You’ll
--have to create those users too.
--5. The order of your migrations matter! For example, since posts depend on users and
--topics, you’ll have to migrate the latter first.
--6. Tip: You can start by running only SELECTs to fine-tune your queries, and use a LIMIT to
--avoid large data sets. Once you know you have the correct query, you can then run your
--full INSERT...SELECT query.
--7. NOTE: The data in your SQL Workspace contains thousands of posts and comments. The
--DML queries may take at least 10-15 seconds to run.

-- migrate to users table
INSERT INTO "users"("username")
  SELECT DISTINCT username  FROM bad_posts
  UNION
  SELECT DISTINCT username  FROM bad_comments
  UNION
  SELECT DISTINCT regexp_split_to_table(upvotes, ',') AS "username"   FROM bad_posts
  UNION
  SELECT DISTINCT regexp_split_to_table(downvotes, ',')AS "username"   FROM bad_posts
  order by username;
  
-- migrate to topics table
INSERT INTO "topics"("name")
 SELECT DISTINCT topic FROM bad_posts;

-- migrate to posts table
INSERT INTO "posts"("title","url","text_content","topic_id","user_id")
SELECT LEFT(bp.title, 100),bp.url::VARCHAR(500),bp.text_content::VARCHAR,t.id,u.id
FROM topics  t 
INNER JOIN bad_posts bp ON bp.topic = t.name 
INNER JOIN users u ON bp.username = u.username;

-- migrate to comments table
INSERT INTO "comments"( "post_id", "user_id", "text_content")
SELECT  p.id,  u.id,  bc.text_content::VARCHAR
FROM bad_comments bc
JOIN users u ON bc.username = u.username
JOIN posts p ON p.id = bc.post_id;

-- migrate to votes table
INSERT INTO "votes" ("post_id","user_id","vote")
SELECT bp.id, u.id,1 AS vote_up
FROM (SELECT id, REGEXP_SPLIT_TO_TABLE(upvotes,',') 
  AS upvote_users FROM bad_posts) bp
JOIN users u ON u.username=bp.upvote_users;

INSERT INTO "votes"("post_id","user_id","vote")
SELECT bp.id, u.id,-1 AS vote_down
FROM (SELECT id, REGEXP_SPLIT_TO_TABLE(downvotes,',') 
  AS downvote_users FROM bad_posts) bp
JOIN users u ON u.username=bp.downvote_users;

--drop  tables
DROP TABLE bad_comments;
DROP TABLE bad_posts;

